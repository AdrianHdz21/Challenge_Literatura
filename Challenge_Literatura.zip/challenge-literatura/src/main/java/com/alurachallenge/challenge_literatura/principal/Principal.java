package com.alurachallenge.challenge_literatura.principal;

import com.alurachallenge.challenge_literatura.model.Autor;
import com.alurachallenge.challenge_literatura.model.CodigoLenguajes;
import com.alurachallenge.challenge_literatura.model.DatosAPI;
import com.alurachallenge.challenge_literatura.model.Libro;
import com.alurachallenge.challenge_literatura.repository.AutorRepository;
import com.alurachallenge.challenge_literatura.repository.LibroIdioma;
import com.alurachallenge.challenge_literatura.repository.LibroRepository;
import com.alurachallenge.challenge_literatura.service.*;
import org.springframework.dao.DataIntegrityViolationException;

import java.util.*;

public class Principal {

    Scanner teclado = new Scanner(System.in);
    private static final String URL_BASE = "https://gutendex.com/books/";
    private final ConsumoAPI consumoApi = new ConsumoAPI();
    private final ConvierteDatos convierteDatos = new ConvierteDatos();
    private LibroRepository libroRepository;
    private AutorRepository autorRepository;

    //constructor
    public Principal() {
    }

    public Principal(LibroRepository repository, AutorRepository autorRepository) {
        this.libroRepository = repository;
        this.autorRepository = autorRepository;
    }

    public void Menu() {
        var opcion = -1;
        while (opcion != 0) {
            var menu = """
                    \n\n
                    \t\t|************************************************|
                    \t\t|*           MENU CHALLENGE LITERATURA          *|
                    \t\t|************************************************| 
                    \t\t|*                 BIENVENIDO                   *|
                    \t\t|************************************************| 
                    \t\t|*   1.  Buscar libros por título               *|
                    \t\t|*   2.  Listar libros almacenados              *| 
                    \t\t|*   3.  Listar autores almacenados             *|
                    \t\t|*   4.  Listar autores de acuerdo a una fecha  *|
                    \t\t|*   5.  Listar libros por idioma               *|
                    \t\t|*   6.  Top 10 libros con más descargas        *|
                    \t\t|*   0.  Salir                                  *|
                    \t\t|************************************************| 
                    """;

            System.out.println(menu);
            System.out.println("***Ingrese la opcion que desea: ");

            try {
                opcion = teclado.nextInt();
                teclado.nextLine();  // Consume la nueva línea

                switch (opcion) {
                    case 1:
                        buscarLibroIngresado();
                        break;
                    case 2:
                        listarLibrosGuardados();
                        break;
                    case 3:
                        listarAutoresGuardados();
                        break;
                    case 4:
                        listarAutoresPorFechaIngresada();
                        break;
                    case 5:
                        listarLibrosPorIdioma();
                        break;
                    case 6:
                        listarLibrosMasDescargados();
                        break;
                    case 0:
                        System.out.println("Gracias por usar la aplicación...");
                        break;
                    default:
                        System.out.println("Opción inválida. Por favor, ingrese un número entre 0 y 6.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Entrada inválida. Por favor, ingrese un número.");
                teclado.nextLine();
                opcion = -1;
            }

            if (opcion != 0) {
                System.out.println("¿Desea continuar? (Si=1/No=0)");
                try {
                    opcion = teclado.nextInt();
                    teclado.nextLine();  // Consume la nueva línea
                    if (opcion != 1 && opcion != 0) {
                        System.out.println("Opción inválida. Terminando la aplicación.");
                        opcion = 0;
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Entrada inválida. Terminando la aplicación.");
                    break;
                }
            }
        }
    }


    private void buscarLibroIngresado() {
        System.out.println("Ingrese el nombre del libro que desea buscar");
        String libroIngresado = teclado.nextLine();
        String libroNombre = libroIngresado.toLowerCase();

        String urlBusqueda = URL_BASE + "?search=" + libroNombre.replace(" ", "+");
        String json = consumoApi.obtenerDatos(urlBusqueda);
        DatosAPI datosApi = convierteDatos.obtenerDatos(json, DatosAPI.class);

        Optional<Libro> libroEncontrado = datosApi.libros().stream()
                .map(Libro::new)
                .findFirst();

        if (libroEncontrado.isPresent()) {
            Libro libro = libroEncontrado.get();
            Autor autor = autorRepository.findByNombreContainsIgnoreCase(libroEncontrado.get().getAutor().getNombre());
            if (autor == null) {
                Autor nuevoAutor = libroEncontrado.get().getAutor();
                autor = autorRepository.save(nuevoAutor);
            }

            try {
                libro.setAutor(autor);
                libroRepository.save(libro);
                System.out.println(libro);
            } catch (DataIntegrityViolationException ex) {
                System.out.println("Título de libro ya existente en la base de datos.");
            }
        } else {
            System.out.println("El libro ingresado, no fue encontrado");
        }
    }

    private void listarLibrosGuardados() {
        List<Libro> libros = libroRepository.findAll();
        libros.stream()
                .forEach(System.out::println);
    }

    private void listarAutoresGuardados() {
        List<Autor> autores = autorRepository.findAll();
        autores.stream().forEach(System.out::println);
    }

    private void listarAutoresPorFechaIngresada() {
        System.out.println("\n***Por favor, ingrese el año en el que desea buscar un autor: ");
        int fechaIngresada;
        String fecha;

        try {
            fechaIngresada = teclado.nextInt();
            fecha = String.valueOf(fechaIngresada);
            List<Autor> autoresPorFecha = autorRepository.buscarAutorPorFecha(fecha);
            if (autoresPorFecha.isEmpty()) {
                System.out.println("\n***No se encontraron registros***");
            } else {
                autoresPorFecha.stream().forEach(System.out::println);
            }

        } catch (Exception e) {
            System.out.println("Escriba una año valido, Ejemplo 1600");
            teclado.nextLine();
        }
    }

    private void listarLibrosPorIdioma() {
        List<LibroIdioma> idiomas = libroRepository.buscarIdiomas();
        idiomas.forEach(i -> System.out.println(
                """
                        Código de idioma: (%s), Idioma: (%s), Cantidad de libros: %d""".formatted(i.getIdioma(), CodigoLenguajes.obtenerLanguaje(i.getIdioma()), i.getCount())
        ));

        System.out.println("\n***Ingresa el código de idioma para listar los libros: ");

        try {
            String codigo = teclado.nextLine().trim();
            if (codigo.length() != 2) {
                throw new InputMismatchException("Código incorrecto, debe contener solo 2 caracteres.");
            }
            boolean encontrado = false;
            for (LibroIdioma idioma : idiomas) {
                if (idioma.getIdioma().equals(codigo)) {
                    libroRepository.findByIdiomaEquals(codigo).forEach(System.out::println);
                    encontrado = true;
                    break;
                }
            }
            if (!encontrado) {
                System.out.println("Código inválido!");
            }
        } catch (InputMismatchException e) {
            System.out.println(e.getMessage());
        }
    }

    private void listarLibrosMasDescargados() {
        System.out.println("El Top 10 de libros con mas descargas son:");
        List<Libro> librosTop10 = libroRepository.findTop10ByOrderByCantidadDeDescargasDesc();
        librosTop10.stream().forEach(System.out::println);
    }
}


