package com.alurachallenge.challenge_literatura.repository;

public interface LibroIdioma {

    String getIdioma();
    Long getCount();


}
