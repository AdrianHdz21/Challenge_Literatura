package com.alurachallenge.challenge_literatura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeLiteraturaApplicationTests {

	@Test
	void contextLoads() {
	}

}
