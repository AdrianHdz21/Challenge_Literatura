package com.alurachallenge.challenge_literatura.service;

public interface IConvierteDatos {

    default <T> T obtenerDatos(String json, Class<T> clase){
        return null;
    }

}
