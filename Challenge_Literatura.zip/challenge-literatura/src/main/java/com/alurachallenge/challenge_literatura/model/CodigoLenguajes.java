package com.alurachallenge.challenge_literatura.model;

import java.util.HashMap;
import java.util.Map;

public class CodigoLenguajes {
    private static final Map<String, String> LANGUAJE_MAP = new HashMap<>();

    static {
        LANGUAJE_MAP.put("en", "Inglés");
        LANGUAJE_MAP.put("es", "Español");
        LANGUAJE_MAP.put("fr", "Francés");
        LANGUAJE_MAP.put("de", "Alemán");
        LANGUAJE_MAP.put("en", "Inglés");
        LANGUAJE_MAP.put("es", "Español");
        LANGUAJE_MAP.put("fr", "Francés");
        LANGUAJE_MAP.put("de", "Alemán");
        LANGUAJE_MAP.put("it", "Italiano");
        LANGUAJE_MAP.put("pt", "Portugués");
        LANGUAJE_MAP.put("ru", "Ruso");
        LANGUAJE_MAP.put("ja", "Japonés");
        LANGUAJE_MAP.put("zh", "Chino");
        LANGUAJE_MAP.put("ko", "Coreano");
        LANGUAJE_MAP.put("ar", "Árabe");
        LANGUAJE_MAP.put("hi", "Hindi");
        LANGUAJE_MAP.put("he", "Hebreo");
        LANGUAJE_MAP.put("tr", "Turco");
        LANGUAJE_MAP.put("nl", "Holandés");
        LANGUAJE_MAP.put("sv", "Sueco");
        LANGUAJE_MAP.put("no", "Noruego");
        LANGUAJE_MAP.put("fi", "Finlandés");
        LANGUAJE_MAP.put("da", "Danés");
        LANGUAJE_MAP.put("pl", "Polaco");
        LANGUAJE_MAP.put("el", "Griego");
        LANGUAJE_MAP.put("cs", "Checo");
        LANGUAJE_MAP.put("hu", "Húngaro");
        LANGUAJE_MAP.put("th", "Tailandés");
        LANGUAJE_MAP.put("vi", "Vietnamita");
        LANGUAJE_MAP.put("id", "Indonesio");
        LANGUAJE_MAP.put("ms", "Malayo");
        LANGUAJE_MAP.put("ro", "Rumano");
        LANGUAJE_MAP.put("bg", "Búlgaro");
        LANGUAJE_MAP.put("uk", "Ucraniano");
        LANGUAJE_MAP.put("sk", "Eslovaco");
        LANGUAJE_MAP.put("hr", "Croata");
        LANGUAJE_MAP.put("sr", "Serbio");
        LANGUAJE_MAP.put("sl", "Esloveno");
        LANGUAJE_MAP.put("lt", "Lituano");
        LANGUAJE_MAP.put("lv", "Letón");
        LANGUAJE_MAP.put("et", "Estonio");

    }

    public static String obtenerLanguaje(String code) {
        return LANGUAJE_MAP.getOrDefault(code, "Idioma desconocido");
    }
}

